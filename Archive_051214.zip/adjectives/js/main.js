window.app = new App();
window.app.initialize();