var ApplicationRouter = Backbone.Router.extend({
	routes: 
	{ 
		"":"showHome",
		"quiz/:id": "showQuiz" 
	},
	showHome:function()
	{
		this.trigger("showHome");
	},
	showQuiz:function(id)
	{
		console.log("ROUTER::showQuiz(" + id+")");
		this.trigger("showQuiz", id);
	}
});
