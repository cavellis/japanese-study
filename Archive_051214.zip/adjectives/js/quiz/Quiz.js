/**
 * A base class for quizzes
 **/
var Quiz = function()
{

}
Quiz.prototype = 
{
	initialize:function(collection, view)
	{

	},

	nextQuestion:function()
  	{

  	},

  	submitHandler:function()
  	{

  	},

  	submitAnswer:function()
  	{

  	},

  	startQuiz:function()
  	{

  	},
  	
  	showInstructions:function()
	{
	
	},

	destroy:function()
	{
		
	}

}