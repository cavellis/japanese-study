 var QuizItemModel = Backbone.Model.extend({
	
	initialize:	function()
	{
	}	

});