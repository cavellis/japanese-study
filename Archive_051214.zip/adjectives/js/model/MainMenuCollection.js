var MainMenuCollection  = Backbone.Collection.extend({
	url: "json/mainmenu.json",
	model: MainMenuModel

});