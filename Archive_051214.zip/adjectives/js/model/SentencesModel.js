 var SentencesModel = Backbone.Model.extend({
	
	initialize:	function()
	{
	}	

});