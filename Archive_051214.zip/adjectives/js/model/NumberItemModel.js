 var NumberItemModel = Backbone.Model.extend({
	// id, number_value, kanji, hiragana
	initialize:	function()
	{
	}	

});