var PreloaderView = Backbone.View.extend({
	el: $('#quiz-preloader'),
	initialize:function () 
	{
		
	}

});